Each file in this directory corresponds to a module.

Within each file the format of the contents are:
`test_name,test_result,time_to_run_test,run_num,machine_id,test_class_order_md5sum,num_test_class,module_path,slug,sha`
