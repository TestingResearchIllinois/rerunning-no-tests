Each file in this directory corresponds to a test.

Within each file the format of the contents are:
test_name,test_result,time_to_run_test,run_num,machine_id
